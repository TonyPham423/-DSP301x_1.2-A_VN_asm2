# Project

Test Grade Calculator

# Description

This is an assignment in the FUNiX's Course

Main file: lastname_firstname_grade_the_exams.py

Input file: class1.txt, class2.txt, etc.

Output file: class1_grade.txt, class2_grade.txt, etc.

Zip file: DSP301x_asm2_phatptfx16499@funix.edu.vn.zip
-- This .zip file contains all the files in this git.--

# License